
# Bellatrix Research Computing — HTML‑only Site

This repository contains a static, dependency‑free website suitable for local viewing and simple hosting.

## Structure
- `index.html` — Landing page
- `apps.html` — RC Apps
- `ops.html` — RC Ops
- `support.html` — RC Support
- `contact.html` — Contact (mailto link)
- `styles.css` — Shared theme (dark navy + cyan)
- `script.js` — Mobile nav + footer year
- `assets/` — Place images/icons here

## How to Run
- Open `index.html` in a browser. That’s it.

## How to Edit
- Update text directly in the HTML files.
- Put images (e.g., `hero.jpg`) in `assets/` then reference them in the markup.
- Change colors by editing CSS variables in `:root` in `styles.css`.

## Deployment
- GitHub Pages: push to a repo and enable Pages (root directory).
- S3/CloudFront or Nginx: upload all files; set `index.html` as default.

## Contact
Placeholder email: `bellatrix-team@example.com` — replace with your real team address.
