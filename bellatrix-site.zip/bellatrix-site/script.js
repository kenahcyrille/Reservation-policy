
// Mobile nav & year
(function(){
  const navToggle = document.getElementById('nav-toggle');
  const navList = document.getElementById('nav-list');
  const yearEl = document.getElementById('year');
  if (navToggle) navToggle.addEventListener('click', ()=> navList.classList.toggle('show'));
  if (yearEl) yearEl.textContent = new Date().getFullYear();
})();
